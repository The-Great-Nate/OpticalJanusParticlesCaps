# pyoptics
 My DDA and Brownian dynamics code
